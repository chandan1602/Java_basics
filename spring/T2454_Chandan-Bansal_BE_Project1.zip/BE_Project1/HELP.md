# Information

## 10 APIs are Created 
Postman Documentation link :
https://documenter.getpostman.com/view/7754516/UVXqEYVv

## Features Implemented:
1. Builder Pattern
2. Adapter Pattern
3. 9 Basic CRUD Operations for Department and Employee
4. Handled Exceptions 
5. Implemented Logger
6. Advanced Feature of adding 100 Records using multithreading 
7. src>files directory contains test data for inserting 100 records