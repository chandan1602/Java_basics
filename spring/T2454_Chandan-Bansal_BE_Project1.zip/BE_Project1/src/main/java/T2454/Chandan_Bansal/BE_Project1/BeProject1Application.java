package T2454.Chandan_Bansal.BE_Project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(BeProject1Application.class, args);
	}

}
