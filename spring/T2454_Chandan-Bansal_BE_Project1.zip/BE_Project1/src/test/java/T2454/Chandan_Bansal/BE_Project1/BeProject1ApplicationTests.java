package T2454.Chandan_Bansal.BE_Project1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
